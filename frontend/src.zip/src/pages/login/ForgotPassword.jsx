import { useState } from "react";

// Base URL of the backend. Set VITE_API_URL in the frontend .env if different
// (for Create React App use REACT_APP_API_URL instead).
const API =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_API_URL) ||
  "http://localhost:5000";

async function post(path, body) {
  const res = await fetch(`${API}/api/auth${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Something went wrong");
  return data;
}

export default function ForgotPassword({ onBackToLogin }) {
  const [step, setStep] = useState(1); // 1 = enter email, 2 = code + new password, 3 = done
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  const goLogin = () =>
    onBackToLogin ? onBackToLogin() : (window.location.href = "/login");

  const sendCode = async (e) => {
    e?.preventDefault();
    setError("");
    setInfo("");
    setLoading(true);
    try {
      const data = await post("/forgot-password", { email });
      setInfo(data.message);
      // In dev mode the backend returns the code so you can test without email
      if (data.devOtp) setInfo(`${data.message} (dev code: ${data.devOtp})`);
      setStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const reset = async (e) => {
    e.preventDefault();
    setError("");
    if (newPassword.length < 8) return setError("Password must be at least 8 characters");
    if (newPassword !== confirm) return setError("Passwords do not match");
    setLoading(true);
    try {
      await post("/reset-password", { email, code, newPassword });
      setStep(3);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={s.wrap}>
      <div style={s.card}>
        <h2 style={s.title}>Forgot password</h2>

        {step === 1 && (
          <form onSubmit={sendCode}>
            <p style={s.text}>Enter your registered email and we'll send you a 6-digit code.</p>
            <input style={s.input} type="email" placeholder="Email" value={email}
              onChange={(e) => setEmail(e.target.value)} required />
            {error && <p style={s.error}>{error}</p>}
            <button style={s.btn} disabled={loading}>{loading ? "Sending..." : "Send code"}</button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={reset}>
            {info && <p style={s.info}>{info}</p>}
            <input style={s.input} inputMode="numeric" maxLength={6} placeholder="6-digit code"
              value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} required />
            <input style={s.input} type="password" placeholder="New password (min 8 characters)"
              value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
            <input style={s.input} type="password" placeholder="Confirm new password"
              value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
            {error && <p style={s.error}>{error}</p>}
            <button style={s.btn} disabled={loading}>{loading ? "Resetting..." : "Reset password"}</button>
            <button type="button" style={s.link} onClick={sendCode} disabled={loading}>
              Resend code
            </button>
          </form>
        )}

        {step === 3 && (
          <div>
            <p style={s.info}>Your password has been reset. You can now log in.</p>
            <button style={s.btn} onClick={goLogin}>Go to login</button>
          </div>
        )}

        {step !== 3 && (
          <button type="button" style={s.link} onClick={goLogin}>Back to login</button>
        )}
      </div>
    </div>
  );
}

const s = {
  wrap: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f1f7ff", padding: 16 },
  card: { background: "#fff", padding: 28, borderRadius: 12, width: "100%", maxWidth: 400, boxShadow: "0 4px 20px rgba(0,0,0,.08)" },
  title: { color: "#123B63", marginTop: 0 },
  text: { color: "#555", fontSize: 14 },
  input: { width: "100%", boxSizing: "border-box", padding: 10, margin: "8px 0", border: "1px solid #ccd6e0", borderRadius: 8, fontSize: 15 },
  btn: { width: "100%", padding: 11, marginTop: 8, background: "#123B63", color: "#fff", border: 0, borderRadius: 8, fontSize: 15, cursor: "pointer" },
  link: { background: "none", border: 0, color: "#123B63", cursor: "pointer", marginTop: 12, display: "block", textDecoration: "underline", fontSize: 14 },
  error: { color: "#c0392b", fontSize: 14 },
  info: { color: "#1e7e34", fontSize: 14 },
};